package bulkConsignment;

public class InputData {

	public static final String ConsignmentExcelPath ="D:\\sandhya\\UploadConsignment.exe";
	
	
//Xpath or ID's list of BulkConsignment tab
	public static final String BulkConsignmentTab_xpath="id('lnkBulkConsignments')/a";
	public static final String BrowseExcel_xpath="id('FileUpload1')";
	public static final String UploadConsignment_xpath="id('btnUpload')";
	
}
